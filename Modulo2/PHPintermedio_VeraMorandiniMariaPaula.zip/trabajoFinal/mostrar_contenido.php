<?php include("header.php");?>

<?php
session_start();

include('conexion.php');?>

<div class="contenido">
<img src="imagenes/cesta-compra.jpg"   alt="inicio">
</div>




