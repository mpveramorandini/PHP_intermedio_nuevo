<?php 

//$conexion_db = mysqli_connect("localhost", "root", "", "php_intermedio_mpv");



$conexion_db = mysqli_connect("localhost", "id20761485_mariapaulavera", "/?G-+d?QS*S=l30s", "id20761485_phpintermedio");
 