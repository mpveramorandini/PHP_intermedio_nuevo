<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>php_intermedio_mpv</title>
  <link rel="stylesheet" href="estilo.css">
</head>

<body>
  
<div class="encabezado">  
<h1 class="titulo">Colegio</h1>
<h2 class="titulo">Sistema de administración</h2>
<ul>
  <li><a href="cargar.php">Cargar Alumno</a></li>
  <li><a href="ver_alumno.php">Ver Alumno</a></li>
  <li><a href="finalizados.php">Finalizados</a></li>
  <li><a href="salir.php">Salir</a></li>
  
</ul>
</div>

